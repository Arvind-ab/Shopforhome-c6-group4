package com.gl.shopforhome.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Data
@NoArgsConstructor
@ToString
@Table(name="category")
public class category {
	
	@Id
	@GeneratedValue
	private Integer categoryId;

	private String categoryName;

	@NaturalId
	private Integer categoryType;

}
