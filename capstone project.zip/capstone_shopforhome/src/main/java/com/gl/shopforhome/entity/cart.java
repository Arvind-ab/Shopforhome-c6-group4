package com.gl.shopforhome.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name="cart")
public class cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long cartId;

	@OneToOne(fetch = FetchType.LAZY)
	private user users;

}
