package com.gl.shopforhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneShopforhomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
